namespace SistemaImpresion
{
    // Las tres estrategias concretas. Cada una tiene su propio "algoritmo" de envio.
    class NotificadorSms : INotificador
    {
        public string Medio { get { return "SMS"; } }

        public void Notificar(string usuario, TrabajoImpresion trabajo)
        {
            Registro.Log("      [SMS]      a " + usuario + ": \"Tu trabajo " + trabajo + " ya se imprimio\"");
        }
    }

    class NotificadorWhatsApp : INotificador
    {
        public string Medio { get { return "WhatsApp"; } }

        public void Notificar(string usuario, TrabajoImpresion trabajo)
        {
            Registro.Log("      [WhatsApp] a " + usuario + ": \"Listo! Imprimimos " + trabajo + "\"");
        }
    }

    class NotificadorEmail : INotificador
    {
        public string Medio { get { return "Email"; } }

        public void Notificar(string usuario, TrabajoImpresion trabajo)
        {
            Registro.Log("      [Email]    a " + usuario + ": Asunto: Impresion completada - " + trabajo);
        }
    }
}
