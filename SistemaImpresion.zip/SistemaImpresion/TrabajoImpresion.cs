using System;

namespace SistemaImpresion
{
    // Un pedido de impresion. Lleva consigo COMO hay que avisarle al usuario.
    class TrabajoImpresion
    {
        // Lo asigna la Impresora al recibirlo (dentro del lock): es el orden de llegada.
        public int Numero { get; internal set; }

        public string Usuario { get; private set; }
        public string Documento { get; private set; }
        public int Paginas { get; private set; }
        public INotificador Notificador { get; private set; }

        public TrabajoImpresion(string usuario, string documento, int paginas, INotificador notificador)
        {
            if (notificador == null) throw new ArgumentNullException("notificador");
            Usuario = usuario;
            Documento = documento;
            Paginas = paginas;
            Notificador = notificador;
        }

        public override string ToString()
        {
            return "#" + Numero + " '" + Documento + "' (" + Paginas + " pag., de " + Usuario + ")";
        }
    }
}
