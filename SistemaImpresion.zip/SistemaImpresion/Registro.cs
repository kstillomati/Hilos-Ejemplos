using System;
using System.Diagnostics;

namespace SistemaImpresion
{
    // Log con hora. Tiene su propio candado para que las lineas de
    // distintos hilos no se mezclen en la consola.
    static class Registro
    {
        private static readonly Stopwatch reloj = Stopwatch.StartNew();
        private static readonly object candadoConsola = new object();

        public static void Log(string mensaje)
        {
            lock (candadoConsola)
            {
                Console.WriteLine(reloj.Elapsed.TotalSeconds.ToString("0.00").PadLeft(6) + "s  " + mensaje);
            }
        }
    }
}
