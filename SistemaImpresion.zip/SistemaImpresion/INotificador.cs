namespace SistemaImpresion
{
    // PATRON STRATEGY: la impresora solo conoce esta interfaz.
    // No sabe si el aviso va por SMS, WhatsApp o Email, ni como se manda.
    interface INotificador
    {
        string Medio { get; }
        void Notificar(string usuario, TrabajoImpresion trabajo);
    }
}
