using System;

namespace SistemaImpresion
{
    // Se lanza cuando se intenta sacar un trabajo y la cola esta cerrada y vacia:
    // no hay nada que imprimir ni va a llegar nada nuevo.
    class ColaVaciaException : Exception
    {
        public ColaVaciaException()
            : base("No hay trabajos en la cola y la impresora esta cerrada.")
        {
        }
    }
}
