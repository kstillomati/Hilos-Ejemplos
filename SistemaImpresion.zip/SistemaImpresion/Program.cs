using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SistemaImpresion
{
    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("=== Sistema de impresion concurrente ===");
            Console.WriteLine();

            // Singleton: no hay "new Impresora()", se pide la instancia unica.
            Impresora impresora = Impresora.Instancia;
            impresora.Iniciar();                         // arranca el hilo consumidor

            Usuario[] usuarios =
            {
                new Usuario("Ana",    TipoNotificacion.Sms,      impresora, 1),
                new Usuario("Beto",   TipoNotificacion.WhatsApp, impresora, 2),
                new Usuario("Carla",  TipoNotificacion.Email,    impresora, 3),
                new Usuario("Diego",  TipoNotificacion.Sms,      impresora, 4),
                new Usuario("Eva",    TipoNotificacion.WhatsApp, impresora, 5)
            };

            List<Thread> hilos = new List<Thread>();
            foreach (Usuario u in usuarios) hilos.Add(u.Iniciar());

            foreach (Thread h in hilos) h.Join();        // esperamos a todos los usuarios...
            impresora.Cerrar();                          // ...cerramos la cola...
            impresora.Esperar();                         // ...y esperamos que se imprima lo que quede

            bool ok = Pruebas.Ejecutar(impresora, usuarios);
            Console.WriteLine();
            Console.WriteLine(ok ? "TODAS LAS PRUEBAS OK" : "HAY PRUEBAS FALLIDAS");
        }
    }
}
