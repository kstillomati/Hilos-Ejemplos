using System;
using System.Threading;

namespace SistemaImpresion
{
    // PRODUCTOR: cada usuario es un hilo que manda un numero aleatorio de trabajos,
    // esperando un tiempo aleatorio entre uno y otro.
    class Usuario
    {
        private static readonly string[] Documentos =
            { "Informe.pdf", "Factura.docx", "Planilla.xlsx", "Contrato.pdf", "Foto.png" };

        private readonly string nombre;
        private readonly TipoNotificacion medio;
        private readonly Impresora impresora;
        private readonly Random rnd;     // uno por usuario (con semilla distinta)

        public int CantidadPlaneada { get; private set; }
        public int Enviados { get; private set; }
        public TipoNotificacion Medio { get { return medio; } }

        public Usuario(string nombre, TipoNotificacion medio, Impresora impresora, int semilla)
        {
            this.nombre = nombre;
            this.medio = medio;
            this.impresora = impresora;
            rnd = new Random(semilla);
            CantidadPlaneada = rnd.Next(2, 6);      // entre 2 y 5 trabajos
        }

        public Thread Iniciar()
        {
            Thread hilo = new Thread(Ejecutar);
            hilo.Name = nombre;
            hilo.Start();
            return hilo;
        }

        private void Ejecutar()
        {
            for (int i = 0; i < CantidadPlaneada; i++)
            {
                Thread.Sleep(rnd.Next(100, 500));   // tiempo aleatorio entre envios

                TrabajoImpresion trabajo = new TrabajoImpresion(
                    nombre,
                    Documentos[rnd.Next(Documentos.Length)],
                    rnd.Next(1, 4),                         // 1 a 3 paginas
                    NotificadorFactory.Crear(medio));       // el usuario elige COMO quiere el aviso

                impresora.Enviar(trabajo);                  // si la cola esta llena, se duerme aca
                Enviados++;
            }
            Registro.Log(nombre + " termino de enviar (" + Enviados + " trabajos)");
        }
    }
}
