using System;
using System.Threading;

namespace SistemaImpresion
{
    // Pruebas de concurrencia, sin framework: se corren al terminar la simulacion
    // y comparan lo que paso con lo que tenia que pasar.
    static class Pruebas
    {
        private static int fallidas;

        public static bool Ejecutar(Impresora impresora, Usuario[] usuarios)
        {
            fallidas = 0;
            Console.WriteLine();
            Console.WriteLine("=================== PRUEBAS ===================");

            // 1) Singleton: 8 hilos piden la instancia a la vez y tiene que ser la misma.
            Impresora[] obtenidas = new Impresora[8];
            Thread[] hilos = new Thread[obtenidas.Length];
            for (int i = 0; i < hilos.Length; i++)
            {
                int k = i;
                hilos[i] = new Thread(() => obtenidas[k] = Impresora.Instancia);
            }
            foreach (Thread h in hilos) h.Start();
            foreach (Thread h in hilos) h.Join();
            bool todasIguales = true;
            foreach (Impresora o in obtenidas)
                if (!ReferenceEquals(o, impresora)) todasIguales = false;
            Verificar("Singleton: 8 hilos obtienen LA MISMA instancia", todasIguales);

            // 2) Nada se pierde ni se duplica: enviados = recibidos = impresos = notificados.
            int enviados = 0;
            foreach (Usuario u in usuarios) enviados += u.Enviados;
            Verificar("Sin perdidas: enviados(" + enviados + ") = recibidos(" + impresora.Recibidos
                      + ") = impresos(" + impresora.Impresos + ") = notificados(" + impresora.Notificados + ")",
                      enviados == impresora.Recibidos
                      && enviados == impresora.Impresos
                      && enviados == impresora.Notificados);

            // 3) Orden: se imprimio exactamente en el orden de llegada.
            Verificar("Orden FIFO: los trabajos se imprimieron en el orden recibido", impresora.OrdenCorrecto);

            // 4) Control de velocidad: la cola nunca supero su capacidad.
            Verificar("Control de velocidad: ocupacion maxima " + impresora.MaxOcupacion
                      + " <= capacidad " + impresora.Capacidad,
                      impresora.MaxOcupacion <= impresora.Capacidad);
            Console.WriteLine("  INFO  los usuarios tuvieron que esperar " + impresora.EsperasDeUsuarios + " vez/veces");

            // 5) Cada medio recibio tantos avisos como trabajos pidieron ese medio.
            foreach (TipoNotificacion tipo in Enum.GetValues(typeof(TipoNotificacion)))
            {
                int esperados = 0;
                foreach (Usuario u in usuarios)
                    if (u.Medio == tipo) esperados += u.Enviados;
                string medio = NotificadorFactory.Crear(tipo).Medio;
                Verificar("Notificaciones por " + medio + ": esperadas " + esperados
                          + ", enviadas " + impresora.NotificacionesDe(medio),
                          esperados == impresora.NotificacionesDe(medio));
            }

            // 6) Excepciones (la impresora ya esta cerrada y vacia).
            Verificar("ObtenerSiguienteTrabajo sin trabajos lanza ColaVaciaException",
                      LanzaExcepcion<ColaVaciaException>(() => impresora.ObtenerSiguienteTrabajo()));
            Verificar("Imprimir(null) lanza ArgumentNullException",
                      LanzaExcepcion<ArgumentNullException>(() => impresora.Imprimir(null)));
            Verificar("Enviar con la impresora cerrada lanza InvalidOperationException",
                      LanzaExcepcion<InvalidOperationException>(() =>
                          impresora.Enviar(new TrabajoImpresion("Test", "x.pdf", 1, NotificadorFactory.Crear(TipoNotificacion.Sms)))));

            Console.WriteLine("===============================================");
            return fallidas == 0;
        }

        private static void Verificar(string descripcion, bool ok)
        {
            if (!ok) fallidas++;
            Console.WriteLine("  " + (ok ? "OK    " : "FALLO ") + descripcion);
        }

        private static bool LanzaExcepcion<T>(Action accion) where T : Exception
        {
            try { accion(); }
            catch (T) { return true; }
            return false;
        }
    }
}
