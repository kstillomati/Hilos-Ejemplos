namespace SistemaImpresion
{
    // Medios por los que el usuario puede pedir que lo avisen.
    enum TipoNotificacion
    {
        Sms,
        WhatsApp,
        Email
    }
}
