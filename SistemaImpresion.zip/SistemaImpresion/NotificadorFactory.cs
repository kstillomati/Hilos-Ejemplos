using System;

namespace SistemaImpresion
{
    // PATRON FACTORY: el Usuario pide "un notificador de tipo X" y la fabrica
    // decide que clase concreta crear. Asi ni el Usuario ni la Impresora
    // hacen "new NotificadorSms()".
    static class NotificadorFactory
    {
        public static INotificador Crear(TipoNotificacion tipo)
        {
            switch (tipo)
            {
                case TipoNotificacion.Sms: return new NotificadorSms();
                case TipoNotificacion.WhatsApp: return new NotificadorWhatsApp();
                case TipoNotificacion.Email: return new NotificadorEmail();
                default:
                    throw new ArgumentOutOfRangeException("tipo", "Tipo de notificacion desconocido: " + tipo);
            }
        }
    }
}
