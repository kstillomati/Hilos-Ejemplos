using System;
using System.Collections.Generic;
using System.Threading;

namespace SistemaImpresion
{
    // Recurso compartido y a la vez CONSUMIDOR del patron Productor-Consumidor.
    //  - Singleton: una sola instancia en toda la aplicacion.
    //  - Cola FIFO acotada protegida con Monitor (control de velocidad).
    //  - Los usuarios (productores) se duermen con Monitor.Wait si la cola esta llena.
    sealed class Impresora
    {
        // ---------------------------------------------------------------
        // PATRON SINGLETON (seguro entre hilos)
        // Lazy<T> garantiza que, aunque 100 hilos pidan Instancia a la vez,
        // el constructor se ejecuta UNA sola vez.
        // ---------------------------------------------------------------
        public const int CAPACIDAD = 3;

        private static readonly Lazy<Impresora> instancia =
            new Lazy<Impresora>(() => new Impresora(CAPACIDAD));

        public static Impresora Instancia
        {
            get { return instancia.Value; }
        }

        // Constructor privado: nadie puede hacer "new Impresora()".
        private Impresora(int capacidad)
        {
            this.capacidad = capacidad;
        }

        // ---------------------------------------------------------------
        // Estado compartido. TODO lo de este bloque se toca solo con 'candado' tomado.
        // ---------------------------------------------------------------
        private readonly Queue<TrabajoImpresion> cola = new Queue<TrabajoImpresion>();
        private readonly object candado = new object();
        private readonly int capacidad;
        private bool cerrada;
        private int ultimoNumeroAsignado;
        private int ultimoNumeroDespachado;

        // Estadisticas para las pruebas.
        private int recibidos;
        private int impresos;
        private int notificados;
        private int maxOcupacion;
        private int esperasDeUsuarios;
        private bool ordenCorrecto = true;
        private readonly Dictionary<string, int> notificacionesPorMedio = new Dictionary<string, int>();

        // La "impresora fisica": hace una impresion por vez.
        private readonly object candadoPapel = new object();

        private Thread hiloConsumidor;

        public int Capacidad { get { return capacidad; } }

        // ---------------------------------------------------------------
        // PRODUCTOR: la llama cada Usuario.
        // ---------------------------------------------------------------
        public void Enviar(TrabajoImpresion trabajo)
        {
            if (trabajo == null) throw new ArgumentNullException("trabajo");

            bool tomado = false;
            try
            {
                Monitor.Enter(candado, ref tomado);

                // CONTROL DE VELOCIDAD: si la cola esta llena, el usuario espera
                // hasta que la impresora saque un trabajo y le avise (PulseAll).
                // WHILE y no IF: al despertar hay que volver a mirar si hay lugar.
                bool yaEsperó = false;
                while (cola.Count == capacidad && !cerrada)
                {
                    if (!yaEsperó)                  // cuento y logueo la espera una sola vez por envio
                    {
                        yaEsperó = true;
                        esperasDeUsuarios++;
                        Registro.Log(trabajo.Usuario + " espera: cola llena " + Ocupacion());
                    }
                    Monitor.Wait(candado);          // suelta el lock y duerme
                }

                if (cerrada)
                    throw new InvalidOperationException("La impresora esta cerrada: no acepta mas trabajos.");

                // El numero se asigna DENTRO del lock: define el orden de llegada
                // real, sin repetidos ni saltos, aunque haya muchos usuarios a la vez.
                trabajo.Numero = ++ultimoNumeroAsignado;
                cola.Enqueue(trabajo);
                recibidos++;
                if (cola.Count > maxOcupacion) maxOcupacion = cola.Count;
                Registro.Log(trabajo.Usuario + " envia " + trabajo + "  " + Ocupacion());

                // PulseAll y no Pulse: en la cola de espera puede haber usuarios Y
                // la impresora; con Pulse podria despertar al equivocado.
                Monitor.PulseAll(candado);
            }
            finally
            {
                if (tomado) Monitor.Exit(candado);
            }
        }

        // ---------------------------------------------------------------
        // CONSUMIDOR: devuelve el proximo trabajo en orden de llegada (FIFO).
        // Si no hay, espera. Si la cola esta cerrada y vacia lanza ColaVaciaException.
        // ---------------------------------------------------------------
        public TrabajoImpresion ObtenerSiguienteTrabajo()
        {
            bool tomado = false;
            try
            {
                Monitor.Enter(candado, ref tomado);

                while (cola.Count == 0 && !cerrada)
                    Monitor.Wait(candado);          // sin espera activa: duerme hasta que llegue algo

                if (cola.Count == 0)                // cerrada y vacia
                    throw new ColaVaciaException();

                TrabajoImpresion trabajo = cola.Dequeue();

                // Verificacion de orden: los numeros tienen que salir 1, 2, 3, 4...
                if (trabajo.Numero != ultimoNumeroDespachado + 1) ordenCorrecto = false;
                ultimoNumeroDespachado = trabajo.Numero;

                Monitor.PulseAll(candado);          // ahora hay lugar: aviso a los usuarios
                return trabajo;
            }
            finally
            {
                if (tomado) Monitor.Exit(candado);
            }
        }

        // ---------------------------------------------------------------
        // Simula la impresion. NO se llama con el lock de la cola tomado:
        // imprimir tarda, y mientras tanto los usuarios tienen que poder encolar.
        // ---------------------------------------------------------------
        public void Imprimir(TrabajoImpresion trabajo)
        {
            if (trabajo == null)
                throw new ArgumentNullException("trabajo", "No hay ningun trabajo para imprimir.");

            lock (candadoPapel)     // una sola impresion por vez, venga de donde venga
            {
                Registro.Log("IMPRESORA imprimiendo " + trabajo + " ...");
                Thread.Sleep(200 * trabajo.Paginas);
                Registro.Log("IMPRESORA termino    " + trabajo);
            }

            lock (candado) { impresos++; }
        }

        // ---------------------------------------------------------------
        // Ciclo de vida: hilo consumidor, cierre y espera.
        // ---------------------------------------------------------------
        public void Iniciar()
        {
            hiloConsumidor = new Thread(ProcesarTrabajos);
            hiloConsumidor.Name = "Impresora";
            hiloConsumidor.Start();
        }

        private void ProcesarTrabajos()
        {
            while (true)
            {
                TrabajoImpresion trabajo;
                try
                {
                    trabajo = ObtenerSiguienteTrabajo();
                }
                catch (ColaVaciaException)
                {
                    Registro.Log("IMPRESORA: cola cerrada y vacia, se apaga");
                    break;
                }

                Imprimir(trabajo);
                Notificar(trabajo);
            }
        }

        // La impresora solo habla con INotificador: no sabe si es SMS, WhatsApp o Email.
        // Si el aviso falla, se registra y la impresora sigue con el proximo trabajo.
        private void Notificar(TrabajoImpresion trabajo)
        {
            try
            {
                trabajo.Notificador.Notificar(trabajo.Usuario, trabajo);

                lock (candado)
                {
                    notificados++;
                    string medio = trabajo.Notificador.Medio;
                    int antes;
                    notificacionesPorMedio.TryGetValue(medio, out antes);
                    notificacionesPorMedio[medio] = antes + 1;
                }
            }
            catch (Exception ex)
            {
                Registro.Log("IMPRESORA: fallo el aviso de " + trabajo + ": " + ex.Message);
            }
        }

        // La llama Main cuando todos los usuarios terminaron.
        public void Cerrar()
        {
            bool tomado = false;
            try
            {
                Monitor.Enter(candado, ref tomado);
                cerrada = true;
                Monitor.PulseAll(candado);          // despierta a la impresora (o a usuarios dormidos)
            }
            finally
            {
                if (tomado) Monitor.Exit(candado);
            }
        }

        public void Esperar()
        {
            if (hiloConsumidor != null) hiloConsumidor.Join();
        }

        // Se llama siempre con 'candado' tomado.
        private string Ocupacion()
        {
            return "[" + new string('#', cola.Count) + new string('.', capacidad - cola.Count) + "]";
        }

        // ---------------------------------------------------------------
        // Lectura de estadisticas (con lock, para ver valores actualizados).
        // ---------------------------------------------------------------
        public int Recibidos { get { lock (candado) { return recibidos; } } }
        public int Impresos { get { lock (candado) { return impresos; } } }
        public int Notificados { get { lock (candado) { return notificados; } } }
        public int MaxOcupacion { get { lock (candado) { return maxOcupacion; } } }
        public int EsperasDeUsuarios { get { lock (candado) { return esperasDeUsuarios; } } }
        public bool OrdenCorrecto { get { lock (candado) { return ordenCorrecto; } } }

        public int NotificacionesDe(string medio)
        {
            lock (candado)
            {
                int n;
                notificacionesPorMedio.TryGetValue(medio, out n);
                return n;
            }
        }
    }
}
